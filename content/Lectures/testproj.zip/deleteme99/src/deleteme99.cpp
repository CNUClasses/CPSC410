//============================================================================
// Name        : deleteme99.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <thread>
#include <iostream>
#include <string>
#include <mutex>

using namespace std;

mutex m;

void fun(string s){

	for (int i=0; i<500;i++){	
		m.lock();
		cout<<s<<s<<s<<s<<s<<endl;
		m.unlock();
	}

}

int main() {
	
	
	
	
	thread t1(fun, "a");
	thread t2(fun, "b");
	thread t3(fun, "c");
	t1.join();
	t2.join();
	t3.join();
	
	
	return 0;
}
